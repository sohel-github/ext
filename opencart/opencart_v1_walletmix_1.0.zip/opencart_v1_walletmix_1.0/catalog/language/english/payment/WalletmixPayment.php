<?php
/**
 * Walletmix - Online Payment Gateway For Bangladesh | Support Local & International Visa Master,DBBL NEXUS
 * PHP4 und PHP5
 *
 * @version 1.1
 * @author golam mostofa <mostofa@bloodsoft.com>
 * @copyright 2012 walletmix.com
 * Free Payment Module for OpenCart.com
 */
$_['heading_title']     = 'Thank you for shopping with %s .... ';

// Text
$_['text_title']        = 'DBBL NEXUS | DBBL MasterDebit | DBBL VisaDebit | Visa | Master | BKash ( WalletmixPayment Payment Gateway )';
$_['text_response']     = 'Response from Walletmix Payment Gateway';
$_['text_success']      = '... your payment was successfully received.';
$_['text_success_wait'] = '<b><span style="color: #FF0000">Please wait...</span></b> whilst we finish processing your order.<br>If you are not automatically re-directed in 10 seconds, please click <a href="%s">here</a>.';
$_['text_failure']      = '... Your payment has been cancelled!';
$_['text_failure_wait'] = '<b><span style="color: #FF0000">Please wait...</span></b><br>If you are not automatically re-directed in 10 seconds, please click <a href="%s">here</a>.';										  
?>