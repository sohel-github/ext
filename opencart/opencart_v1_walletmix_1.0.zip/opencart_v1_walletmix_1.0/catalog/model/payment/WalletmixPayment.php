<?php
/**
 * Walletmix - Online Payment Gateway For Bangladesh | Support Local & International Visa Master,DBBL NEXUS
 * PHP4 und PHP5
 *
 * @version 1.1
 * @author golam mostofa <mostofa@bloodsoft.com>
 * @copyright 2012 walletmix.com
 * Free Payment Module for OpenCart.com
 */
class ModelPaymentWalletmixPayment extends Model {
  	
	
	public function getMethod($address, $total) {
	$this->language->load('payment/WalletmixPayment');
	
	$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "zone_to_geo_zone WHERE geo_zone_id = '" . (int)$this->config->get('WalletmixPayment_geo_zone_id') . "' AND country_id = '" . (int)$address['country_id'] . "' AND (zone_id = '" . (int)$address['zone_id'] . "' OR zone_id = '0')");

		if ($this->config->get('WalletmixPayment_total') > 0 && $this->config->get('WalletmixPayment_total') > $total) {
			$status = false;
		} elseif (!$this->config->get('WalletmixPayment_geo_zone_id')) {
			$status = true;
		} elseif ($query->num_rows) {
			$status = true;
		} else {
			$status = false;
		}

		$method_data = array();
		

		if ($status) {
			$method_data = array(
				'code'       => 'WalletmixPayment',
				'title'      => $this->language->get('text_title'),
				'sort_order' => $this->config->get('WalletmixPayment_sort_order')
			);
		}

		return $method_data;
	
	
	
	
	}
}
?>