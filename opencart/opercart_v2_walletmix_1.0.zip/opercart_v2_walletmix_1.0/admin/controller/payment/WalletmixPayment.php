<?php
/**
 * Walletmix - Online Payment Gateway For Bangladesh | Support Local & International Visa Master,DBBL NEXUS
 * PHP4 and PHP5
 *
 * @version 1.1
 * @author golam mostofa <mostofa@bloodsoft.com>
 * @copyright 2012 walletmix.com
 * Free Payment Module for OpenCart.com
 */
class ControllerPaymentWalletmixPayment extends Controller {
	private $error = array();

	public function index() 
	{
	$this->load->language('payment/WalletmixPayment');
	//$this->language->load('payment/WalletmixPayment');
	$this->document->setTitle($this->language->get('heading_title'));
	
	
	$this->load->model('setting/setting');
	
	if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
			$this->model_setting_setting->editSetting('WalletmixPayment', $this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$this->response->redirect($this->url->link('extension/payment', 'token=' . $this->session->data['token'], 'SSL'));
			
		}
		
		
		$data['heading_title'] = $this->language->get('heading_title');

		$data['text_enabled'] = $this->language->get('text_enabled');
		$data['text_disabled'] = $this->language->get('text_disabled');
		$data['text_all_zones'] = $this->language->get('text_all_zones');
		$data['text_yes'] = $this->language->get('text_yes');
		$data['text_no'] = $this->language->get('text_no');
		$data['text_live'] = $this->language->get('text_live');
		$data['text_successful'] = $this->language->get('text_successful');
		$data['text_fail'] = $this->language->get('text_fail');
		
		$data['edit_text'] = $this->language->get('edit_text');

		$data['entry_merchant'] = $this->language->get('entry_merchant');
		$data['entry_callback'] = $this->language->get('entry_callback');
		$data['entry_website_url'] = $this->language->get('entry_website_url');
		$data['help_callback'] = $this->language->get('help_callback');
		$data['entry_order_status'] = $this->language->get('entry_order_status');
		$data['entry_status'] = $this->language->get('entry_status');
		$data['entry_sort_order'] = $this->language->get('entry_sort_order');

		$data['button_save'] = $this->language->get('button_save');
		$data['button_cancel'] = $this->language->get('button_cancel');
		
		
		$data['notes'] = $this->language->get('notes');
		$data['merchant_notes'] = $this->language->get('merchant_notes');
		

 		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->error['merchant'])) {
			$data['error_merchant'] = $this->error['merchant'];
		} else {
			$data['error_merchant'] = '';
		}

  		$data['breadcrumbs'] = array();

   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('text_home'),
			'href'      => $this->url->link('common/home', 'token=' . $this->session->data['token'], 'SSL'),
      		'separator' => false
   		);

   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('text_payment'),
			'href'      => $this->url->link('extension/payment', 'token=' . $this->session->data['token'], 'SSL'),
      		'separator' => ' :: '
   		);

   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('heading_title'),
			'href'      => $this->url->link('payment/WalletmixPayment', 'token=' . $this->session->data['token'], 'SSL'),
      		'separator' => ' :: '
   		);

		$data['action'] = $this->url->link('payment/WalletmixPayment', 'token=' . $this->session->data['token'], 'SSL');

		$data['cancel'] = $this->url->link('extension/payment', 'token=' . $this->session->data['token'], 'SSL');

		$data['callback'] = HTTP_CATALOG . 'index.php?route=payment/WalletmixPayment/callback';
		
		$data['website_url']=HTTP_CATALOG;
		
		if (isset($this->request->post['WalletmixPayment_merchant'])) {
			$data['WalletmixPayment_merchant'] = $this->request->post['WalletmixPayment_merchant'];
		} else {
			$data['WalletmixPayment_merchant'] = $this->config->get('WalletmixPayment_merchant');
		}
	

		if (isset($this->request->post['WalletmixPayment_order_status_id'])) {
			$data['WalletmixPayment_order_status_id'] = $this->request->post['WalletmixPayment_order_status_id'];
		} else {
			$data['WalletmixPayment_order_status_id'] = $this->config->get('WalletmixPayment_order_status_id');
		}

		$this->load->model('localisation/order_status');

		$data['order_statuses'] = $this->model_localisation_order_status->getOrderStatuses();



		if (isset($this->request->post['WalletmixPayment_status'])) {
			$data['WalletmixPayment_status'] = $this->request->post['WalletmixPayment_status'];
		} else {
			$data['WalletmixPayment_status'] = $this->config->get('WalletmixPayment_status');
		}


		if (isset($this->request->post['WalletmixPayment_sort_order'])) {
			$data['WalletmixPayment_sort_order'] = $this->request->post['WalletmixPayment_sort_order'];
		} else {
			$data['WalletmixPayment_sort_order'] = $this->config->get('WalletmixPayment_sort_order');
		}

		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		
		$this->response->setOutput($this->load->view('payment/WalletmixPayment.tpl', $data));
		
	
	
	
	
	}

	
	
	
	private function validate() 
	{
	
	
		if (!$this->user->hasPermission('modify', 'payment/WalletmixPayment')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		if (!$this->request->post['WalletmixPayment_merchant']) {
			$this->error['merchant'] = $this->language->get('error_merchant');
		}

		if (!$this->error) {
			return true;
		} else {
			return false;
		}
	
	
	
	
	
	}
}
?>