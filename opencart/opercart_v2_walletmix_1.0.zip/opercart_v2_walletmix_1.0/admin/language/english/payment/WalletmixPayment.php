<?php
/**
 * Walletmix - Online Payment Gateway For Bangladesh | Support Local & International Visa Master,DBBL NEXUS
 * PHP4 und PHP5
 *
 * @version 1.1
 * @author golam mostofa <mostofa@bloodsoft.com>
 * @copyright 2012 walletmix.com
 * Free Payment Module for OpenCart.com
 */
$_['heading_title']      = 'Walletmix';

// Text
$_['text_payment']       = 'Payment';
$_['text_success']       = 'Success: You have modified Walletmix account details!';
$_['text_WalletmixPayment']      = '<a onclick="window.open(\'https://www.walletmix.com/\');"><img src="view/image/payment/Walletmix.png" alt="Walletmix" title="Walletmix" style="border: 1px solid #EEEEEE;" /></a>';
$_['text_live']          = 'Production';
$_['text_successful']    = 'Always Successful';
$_['text_fail']          = 'Always Fail';

$_['edit_text']          = 'Edit Walletmix';

// Entry
$_['entry_merchant']     = 'Merchant ID';
$_['entry_callback']     = 'Relay Response Url';
$_['entry_website_url']  = 'Website URL';
$_['entry_order_status'] = 'Order Status:';
$_['entry_status']       = 'Status:';
$_['entry_sort_order']   = 'Sort Order';

//help

$_['help_callback']      = 'This has to be set in the Walletmix control panel.';

// Error
$_['error_permission']   = 'Warning: You do not have permission to modify payment Walletmix! You Must have EasyPayWay Marchant ID to Active the Account. Please Contact with Walletmix for Marchant.<a href="https://www.walletmix.com/" target="_blank">Click to Contact</a>';
$_['error_merchant']     = 'Merchant ID Required!';
//note
$_['notes']              = '<b>Note: </b>copy this url during merchant registration at <a href="https://www.walletmix.com/register" target="blank">Walletmix</a>.';
$_['merchant_notes']              = '<b>Note:</b> You can get this from <a href="https://www.walletmix.com/register" target="blank">Walletmix</a>';


?>