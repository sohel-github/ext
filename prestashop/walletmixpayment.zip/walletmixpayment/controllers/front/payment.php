<?php

/*
*  @author Golam Mostofa <mostofa@bloodsoft.com>
*/

class WalletmixpaymentPaymentModuleFrontController extends ModuleFrontController
{

	public function initContent()
	{
		parent::initContent();

		$cart = $this->context->cart;
		
		$customer = new Customer((int)($cart->id_customer));
		$currency = new Currency((int)($cart->id_currency));
		/* delivery address */
		$address = new Address((int)($cart->id_address_delivery));
		$state= new State((int)$address->id_state);
		/* invoice address */
		$invoiceAddress=new Address((int)($cart->id_address_invoice));
		$stateInvoice=new State((int)$invoiceAddress->id_state);
		/* shop info */
		$shop=new Shop((int)($cart->id_shop));
		
		$product_wtihquantity=''; 
		$length=0;
		$quantity=0;
		$products=$cart->getProducts();
		
		foreach($products as $product)
		{
		$price=$product['price'];
		$t=$product['total'];
		$product_wtihquantity.='{'.$product['cart_quantity']. 'x' . $product['name']. '['.$price.']=['.$t.']}+';
		$length++;
		$quantity+=$product['cart_quantity'];
		}
		
		$shipping=number_format($cart->getOrderTotal(true,5), 2, '.', '');
		$coupon=number_format($cart->getOrderTotal(true,2), 2, '.', '');
		
		
		$product_wtihquantity.='{shipping rate:'.$shipping.'}-{discount amount:'.$coupon.'}='.number_format($cart->getOrderTotal(), 2, '.', '');
		
		$order_id=(int)$cart->id;
		$shop_id=$cart->id_shop;
		$shop_title=$shop->name;
		
		$cart_info=Configuration::get('MERCHANT_ID').','.Configuration::get('WEBSITE_URL').','.$shop_id.':'.$shop_title.','.$customer->email.','.$order_id;
		
		$options=base64_encode('s='.Configuration::get('WEBSITE_URL').',i='.$_SERVER['SERVER_ADDR']);
		
		
		$products="Order-$order_id"."_".$cart->date_upd;
		
		
		$callbackUrl=(Configuration::get('PS_SSL_ENABLED') ? 'https' : 'http').'://'.$_SERVER['HTTP_HOST'].__PS_BASE_URI__.'modules/'.$this->module->name.'/validation.php';
		
		$wallemixParams=array();
		
		$wallemixParams['merchant_id']=Configuration::get('MERCHANT_ID');
		$wallemixParams['order_info']=$cart_info;
		$wallemixParams['amount']=number_format($cart->getOrderTotal(), 2, '.', '');
		/* customer part */
		$wallemixParams['cus_name']=$invoiceAddress->firstname.' '.$invoiceAddress->lastname;
		$wallemixParams['cus_add1']=$invoiceAddress->address1;
		$wallemixParams['cus_add2']=$invoiceAddress->address2;
		$wallemixParams['cus_city']=$invoiceAddress->city;
		$wallemixParams['cus_state']=$stateInvoice->name;
		$wallemixParams['cus_postcode']=$invoiceAddress->postcode;
		
		$wallemixParams['cus_country']=$invoiceAddress->country;
		
		$wallemixParams['cus_phone']=!empty($invoiceAddress->phone_mobile) ? $invoiceAddress->phone_mobile : $invoiceAddress->phone;
		
		$wallemixParams['cus_email']=$customer->email;
		/* shipping part */
		$wallemixParams['ship_name']=$address->firstname.' '.$address->lastname;
		$wallemixParams['ship_add1']=$address->address1;
		$wallemixParams['ship_add2']=$address->address2;
		$wallemixParams['ship_city']=$address->city;
		$wallemixParams['ship_state']=$state->name;
		$wallemixParams['ship_postcode']=$address->postcode;
		$wallemixParams['ship_country']=$address->country;
		/* others */
		$wallemixParams['currency']=$currency->iso_code;
		$wallemixParams['callback_url']=$callbackUrl;
		$wallemixParams['cancel_url']=Configuration::get('WALLETMIX_CANCEL_URL');
		$wallemixParams['opt_a']=$options;
		$wallemixParams['description']=$product_wtihquantity;
		$wallemixParams['bankdescription']=$products;
		$wallemixParams['product_length']=$length;
		$wallemixParams['quantity']=$quantity;
		
		$this->context->smarty->assign(
		array(
		'nbProducts' => $cart->nbProducts(),
		'total' => $cart->getOrderTotal(true, Cart::BOTH),
		'this_path' => $this->module->getPathUri(),
		'this_path_walletmix' => $this->module->getPathUri(),
		'walletmixParams'=>$wallemixParams
		)
		);
	
		$this->setTemplate('payment_execution.tpl');
		
		
		
	}



}