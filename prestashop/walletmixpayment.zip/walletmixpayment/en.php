<?php
global $_MODULE;
$_MODULE = array();
$_MODULE['<{walletmixpayment}prestashop>payment_46b9e3665f187c739c55983f757ccda0'] = 'I confirm my order';