<?php
/*
* 2013-2015 Walletmix

* needs please refer to https://www.walletmix.com for more information.
*
*  @author Golam Mostofa <mostofa@bloodsoft.com>
*  @copyright  2013-2015 Walletmix Limited
*/
				    	
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
header("Last-Modified: ".gmdate("D, d M Y H:i:s")." GMT");
						
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
						
header("Location: ../");
exit;
