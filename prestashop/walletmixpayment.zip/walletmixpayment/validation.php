<?php
/*


*/
include(dirname(__FILE__).'/../../config/config.inc.php');
include(dirname(__FILE__).'/../../header.php');
include(dirname(__FILE__).'/walletmixpayment.php');

$context = Context::getContext();
$cart = $context->cart;
$walletmix=new Walletmixpayment();
$customer = new Customer($cart->id_customer);

$status=$_POST['pay_status'];


$message = '';

$messageArray=array(
'Payment status'=>$_POST['pay_status'],
'Walletmix Transaction ID'=>$_POST['walletmix_txnid'],
'Your Oder id'=>$_POST['mer_txnid'],
'Currency merchant'=>$_POST['currency_merchant'],
'Currency walletmix'=>$_POST['currency'],
'Currency conversion rate'=>$_POST['convertion_rate'],
'Receiveable amount after Walletmix service'=>$_POST['store_amount'],
'Payment date'=>$_POST['pay_time'],
'Bank Transaction ID'=>$_POST['bank_txn'],
'Card number'=>$_POST['card_number'],
'Card name'=>$_POST['card_name'],
'Card type'=>$_POST['card_type'],
'Customer IP addresss'=>$_POST['ip_address'],
'Currency charged in BDT'=>$_POST['walletmix_service_charge_bdt'],
'Reason'=>$_POST['reason'],
);

foreach($messageArray as $k=>$v)
{
$message .= $k."=".$v."\n";
}

$message = nl2br(strip_tags($message));

$id_cart = (int)($_POST['mer_txnid']);

	

$currency = $context->currency;
$total = (float)$cart->getOrderTotal(true, Cart::BOTH);


if($status == "success")
{
$walletmix->validateOrder((int)($id_cart),Configuration::get('PS_OS_WS_PAYMENT'),$total,$walletmix->displayName,$message,array(),NULL,false,$customer->secure_key);

Tools::redirect('index.php?controller=order-confirmation&id_cart='.(int)($cart->id).'&id_module='.(int)($walletmix->id).'&id_order='.$walletmix->currentOrder.'&key='.$customer->secure_key);

}
else if($status == "failed")
{
$walletmix->validateOrder((int)($id_cart),Configuration::get('PS_OS_ERROR'),$total,$walletmix->displayName,$message,array(),NULL,false,$customer->secure_key);

Tools::redirect('index.php?controller=order-confirmation&id_cart='.(int)($cart->id).'&id_module='.(int)($walletmix->id).'&id_order='.$walletmix->currentOrder.'&key='.$customer->secure_key);

}
else
{
Tools::redirect('index.php?controller=order&step=1');
}


