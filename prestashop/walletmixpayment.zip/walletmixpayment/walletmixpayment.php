<?php
if (!defined('_PS_VERSION_'))
exit;

class Walletmixpayment extends PaymentModule
{
	private $_html = '';
	private $_postErrors = array();

	public function __construct()
	{
		$this->name = 'walletmixpayment';
		$this->tab = 'payments_gateways';
		$this->version = '1.0.0';
		$this->author = 'Golam Mostofa';
		$this->need_instance = 0;
		$this->ps_versions_compliancy = array('min' => '1.6', 'max' => _PS_VERSION_); 
		$this->bootstrap = true;
	 
		parent::__construct();
	 
		$this->page = basename(__FILE__, '.php');
		$this->displayName = $this->l('Walletmix Payment Gateway');
		$this->description = $this->l('Walletmix is Bangladeshi Payment Gateway.');
	 
		$this->confirmUninstall = $this->l('Are you sure you want to uninstall?');
	 
		if (Configuration::get('MERCHANT_ID') == '')      
		  $this->warning = $this->l('No MERCHANT_ID provided');
	}
	
	public function install()
	{
	  if (!parent::install() OR
		!$this->registerHook('payment') OR
		!$this->registerHook('paymentReturn'))
		return false;
		
		Configuration::updateValue('WALLETMIX_CANCEL_URL', (Configuration::get('PS_SSL_ENABLED') ? 'https' : 'http').'://'.$_SERVER['HTTP_HOST'].__PS_BASE_URI__);
		Configuration::updateValue('WEBSITE_URL', (Configuration::get('PS_SSL_ENABLED') ? 'https' : 'http').'://'.$_SERVER['HTTP_HOST'].__PS_BASE_URI__);
		
	  return true;
	}

	public function uninstall()
	{
	  if (!parent::uninstall())
	  return false;
	  
	  Configuration::deleteByName('MERCHANT_ID');
	  Configuration::deleteByName('WALLETMIX_CANCEL_URL');
	  Configuration::deleteByName('WEBSITE_URL');
	  return true;
	}
	
	private function _postValidation()
	{
		if (Tools::isSubmit('btnSubmit'))
		{
			if (!Tools::getValue('MERCHANT_ID'))
				$this->_postErrors[] = $this->l('MERCHANT ID field is required.');
			
		}
	}
	
	private function _postProcess()
	{
		if (Tools::isSubmit('btnSubmit'))
		{
			Configuration::updateValue('MERCHANT_ID', Tools::getValue('MERCHANT_ID'));
		}
		$this->_html .= $this->displayConfirmation($this->l('Settings updated'));
	}
	
	private function _displayWalletmixpayment()
	{
		return $this->display(__FILE__, 'walletmix_infos.tpl');
	}
	
	
	public function getContent()
	{
	
	$this->_html = '';
	
	if (Tools::isSubmit('btnSubmit'))
	{
			$this->_postValidation();
			if (!count($this->_postErrors))
				$this->_postProcess();
			else
				foreach ($this->_postErrors as $err)
					$this->_html .= $this->displayError($err);
	}
	
	$this->_html .= $this->_displayWalletmixpayment();
	$this->_html .= $this->renderForm();

	return $this->_html;
	
	}
	
	public function renderForm()
	{
		
	$fields_form = array(
			'form' => array(
				'legend' => array(
					'title' => $this->l('Walletmix Details'),
					'icon' => 'icon-envelope'
				),
				'input' => array(
					array(
						'type' => 'text',
						'label' => $this->l('MERCHANT ID'),
						'name' => 'MERCHANT_ID',
						'required' => true,
						'desc'     => 'you can get this from <a href="https://www.walletmix.com/register" target="_blank">Walletmix</a>.' 
					),
					array(
					'type'=>'text',
					'label'=>$this->l('Your WebSite Url'),
					'name'=>'WEBSITE_URL',
					'disabled'=>true,
					'desc'=>$this->l('copy this url during merchant registration.').'&nbsp;<span style="background-color: #181818 ;color: white;padding: 5px 10px;">'.Configuration::get('WEBSITE_URL').'</span>'
					)
				),
				'submit' => array(
					'title' => $this->l('Save'),
				)
			),
	);
	$helper = new HelperForm();	
	$lang = new Language((int)Configuration::get('PS_LANG_DEFAULT'));
	$helper->default_form_language = $lang->id;
	$helper->identifier = $this->identifier;
	$helper->submit_action = 'btnSubmit';
	$helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false).'&configure='.$this->name.'&tab_module='.$this->tab.'&module_name='.$this->name;
	$helper->token = Tools::getAdminTokenLite('AdminModules');
	
	$helper->tpl_vars = array(
			'fields_value' => $this->getConfigFieldsValues(),
			'id_language' => $this->context->language->id
	);
	
	return $helper->generateForm(array($fields_form));
	
	}

	
	public function getConfigFieldsValues()
	{
		return array(
			'MERCHANT_ID' => Tools::getValue('MERCHANT_ID', Configuration::get('MERCHANT_ID')),
		'WEBSITE_URL'=>Tools::getValue('WEBSITE_URL', Configuration::get('WEBSITE_URL'))
		);
	}
	
	
	
	public function hookPayment($params)
	{
	
	$merchant_id=Configuration::get('MERCHANT_ID');
	
	if (!$this->active || empty($merchant_id))
	return ;
	
	$this->smarty->assign(
	array(
	'this_path_walletmix'=>$this->_path,
	)
	);
	
	return $this->display(__FILE__, 'walletmixpayment.tpl');
	
	}
	
	
	public function hookPaymentReturn($params)
	{
	
	if (!$this->active)
	return ;
	
	
	switch($params['objOrder']->getCurrentState())
	{
		case _PS_OS_WS_PAYMENT_:
		$this->smarty->assign('status', 'ok');
		break;
		
		case _PS_OS_ERROR_:
		default:
		$this->smarty->assign('status', 'failed');
		break;
		
	}
	
	return $this->display(__FILE__, 'confirmation.tpl');
	
	}
	
	
}
?>