<?php

# Required File Includes
include("../../../dbconnect.php");
include("../../../includes/functions.php");
include("../../../includes/gatewayfunctions.php");
include("../../../includes/invoicefunctions.php");



$gatewaymodule = "walletmix"; # Enter your gateway module name here replacing template

$GATEWAY = getGatewayVariables($gatewaymodule);
if (!$GATEWAY["type"]) die("Module Not Activated"); # Checks gateway module is active before accepting callback

$status=$_POST['pay_status'];
$invoiceid = $_POST["mer_txnid"];
$transid = $_POST["bank_txn"];
$amount = $_POST["store_amount"];
$fee = $_POST["walletmix_service_charge_bdt"]; 

$invoiceid = checkCbInvoiceID($invoiceid,$GATEWAY["name"]);
checkCbTransID($transid);

$url=$GATEWAY["systemurl"]."/modules/gateways/callback/walletmix_result.php?result=";

if ($status=="success") {
    # Successful
    addInvoicePayment($invoiceid,$transid,$amount,$fee,$gatewaymodule); # Apply Payment to Invoice: invoiceid, transactionid, amount paid, fees, modulename
	logTransaction($GATEWAY["name"],$_POST,"Successful"); # Save to Gateway Log: name, data array, status				
	?>    
    <script type="text/javascript">   
	setTimeout(
	function()
	{
	window.location="<?php echo $url; ?>success";	
	},
	2000
	);
	</script>    
    <?php		
} else {
	# Unsuccessful
    logTransaction($GATEWAY["name"],$_POST,"Unsuccessful"); # Save to Gateway Log: name, data array, status		
	?>    
    <script type="text/javascript">   
	setTimeout(
	function()
	{
	window.location="<?php echo $url; ?>failed";	
	},
	2000
	);
	</script>        
    <?php	
}
?>