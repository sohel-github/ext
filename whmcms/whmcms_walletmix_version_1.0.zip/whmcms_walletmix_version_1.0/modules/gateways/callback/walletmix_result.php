<?php

//include("../../../includes/functions.php");

if(isset($_GET['result']))
{
$result=$_GET['result'];
$class=$result=="success"?"success":"danger";
$message=$result=="success"?"Your Transaction is successful":"Your Transaction is failed";
}
else
{
$result="Nothing";
$message="Nothing To Display";
}


define("CLIENTAREA",true);
require("../../../init.php");
$ca = new WHMCS_ClientArea();
$ca->setPageTitle($result);
$ca->addToBreadCrumb('index.php',$whmcs->get_lang('globalsystemname'));
$ca->initPage();
$ca->assign('result', ucfirst($result));
$ca->assign('message', $message);

if ($ca->isLoggedIn()) {
 
   # User is logged in - put any code you like here
 
   # Here's an example to get the currently logged in clients first name
 
   $result = mysql_query("SELECT firstname FROM tblclients WHERE id=".$ca->getUserID());
   $data = mysql_fetch_array($result);
   $clientname = $data[0];
 
   $ca->assign('clientname', $clientname);
 
 } else {
 
   # User is not logged in
 
 }


$ca->setTemplate('walletmix_result');
$ca->output();
/*
function walletmix_Result($vars) {

return array(
        'templatefile' => 'contact',
        'vars' => array(
            'result' => $result,
            'message' => $message,
        ),
    );

}
*/
?>

