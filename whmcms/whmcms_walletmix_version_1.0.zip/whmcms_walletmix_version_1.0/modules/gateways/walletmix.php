<?php

function walletmix_config() {

    
    $result = mysql_query("SELECT value FROM tblconfiguration WHERE setting ='SystemURL'");
    $data = mysql_fetch_array($result);
    $systemurl = $data[0];

    
   $configarray = array(
     "FriendlyName" => array("Type" => "System", "Value"=>"Walletmix"),
     "username" => array("FriendlyName" => "Merchant ID", "Type" => "text", "Size" => "20", ),
     "instructions" => array("FriendlyName" => "Payment Instructions", "Type" => "textarea", "Rows" => "5", "Description" => "Do this then do that etc...","Default" =>"You are now going to pay via walletmix payment gateway." ),
     "website_url"=>array("FriendlyName" => "Website Url","Type" => "text","Size" => "65","Default" =>$systemurl,"Disabled"=>"disabled",
     "Description" => "<br>Copy this url during merchant registration. Do not change this, otherwise it will not work.")	  
    ); 
    
    return $configarray;
}




function walletmix_link($params) {

	# Gateway Specific Variables
	$gatewayusername = $params['username'];
	//$gatewaycallback = $params['callback_url'];
	
	if(empty($gatewayusername))
	return '<h1>Merchant Id missing.</h1>';

	# Invoice Variables
	$invoiceid = $params['invoiceid'];
	$description = $params["description"];
	$amount = $params['amount']; # Format: ##.##
	$currency = $params['currency']; # Currency Code

	# Client Variables
	$firstname = $params['clientdetails']['firstname'];
	$lastname = $params['clientdetails']['lastname'];
	$email = $params['clientdetails']['email'];
	$address1 = $params['clientdetails']['address1'];
	$address2 = $params['clientdetails']['address2'];
	$city = $params['clientdetails']['city'];
	$state = $params['clientdetails']['state'];
	$postcode = $params['clientdetails']['postcode'];
	$country = $params['clientdetails']['country'];
	$phone = $params['clientdetails']['phonenumber'];

	# System Variables
	$companyname = $params['companyname'];
	$systemurl = $params['systemurl'];
	$currency = $params['currency'];
	
	
	# processing for walletmix send
	$cart_info=$gatewayusername.','.$systemurl.','.$invoiceid.':'.$companyname.','.$email.','.$invoiceid;		
	
	$option=base64_encode('s='.$systemurl.',i='.$_SERVER['SERVER_ADDR']);
	
	$bankDescription=$description;
	
	$curlData=array(
				'merchant_id'=>$gatewayusername,
				'order_info'=>$cart_info,
				'amount'=>$amount,
				'cus_name'=>$firstname.' '.$lastname,
				'cus_add1'=>$address1,
				'cus_add2'=>$address2,	
				'cus_city'=>$city,
				'cus_state'=>$state,	
				'cus_postcode'=>$postcode,
				'cus_country'=>$country,
				'cus_phone'=>$phone,
				'cus_email'=>$email,
				'currency'=>$currency,
				//'callback_url'=>$gatewaycallback,
				'callback_url'=>$systemurl.'/modules/gateways/callback/walletmix.php',
				'opt_a'=>$option,
				'description'=>$description,
				'bankdescription'=>$bankDescription,
				'product_length'=>1,
				'quantity'=>1
			);
			

	# Enter your code submit to the gateway...
	
	$code='';
	if(!empty($params['instructions']))
	{
	$code='<h1>'.$params['instructions'].'</h1>';
	$code.='<form method="post" action="https://www.walletmix.com/site/payprocess">';
	}
	else
	{
	$code='<form method="post" action="https://www.walletmix.com/site/payprocess">';
	}
	
	foreach($curlData as $k=>$v)
	{
	$code.='<input type="hidden" name="'.$k.'" value="'.$v.'" />';			
	}	
	$code.='<input type="submit" value="Pay Now" />';
	$code.='</form>';
	
	return $code;
}



?>