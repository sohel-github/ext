<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}


/*
Plugin Name: WooCommerce Walletmix Payment Gateway
Plugin URI: http://www.walletmix.com
Description: Walletmix Payment gateway for woocommerce
Version: 0.1
Author: Golam Mostofa
Author Email : mostofa@bloodsoft.com
Author URI: http://www.walletmix.com
*/

add_action('plugins_loaded', 'woocommerce_mostofa_walletmix_init', 0);

function woocommerce_mostofa_walletmix_init(){
  if(!class_exists('WC_Payment_Gateway')) return;

  class WC_Mostofa_Walletmix extends WC_Payment_Gateway{
    
	
	public function __construct(){
      
	  $this -> id = 'walletmix';
	  $this -> has_fields = false;
	  $this->order_button_text  = __( 'Proceed to Walletmix', 'woocommerce' );
      $this -> medthod_title = __( 'Walletmix', 'woocommerce' );      
	  $this->method_description = __( 'Walletmix payment gateway works by sending the user to Bank through Walletmix to enter their payment information.', 'woocommerce' );

      $this -> init_form_fields();
      $this -> init_settings();   
	  
	  $this -> title="Walletmix";
	  $this -> description ="Pay securely by Visa,Master,Nexus card through Walletmix Secure Servers.";
	  
      $this -> merchant_id = $this ->settings['merchant_id'];     
 
	  $this->url='https://www.walletmix.com/site/payprocess';    	
	  
	  
	  
	  add_action( 'woocommerce_api_'.strtolower(get_class($this)), array(&$this, 'check_walletmix_response' ) );
	  
	  /* 1.6.6 */
	  add_action( 'woocommerce_update_options_payment_gateways', array( $this, 'process_admin_options' ) );
	  /* 2.0.0 */
	  add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
	   
      add_action('woocommerce_receipt_'.$this->id, array(&$this, 'receipt_page'));
	  
	 
	  
   }
    
	
	
	/**
	 * get_icon function.
	 *
	 * @return string
	 */
	public function get_icon() {
		
	$icon=plugins_url( '/assets/images/walletmix.png', __FILE__ );
	
	$icon_html = '<img src="' . esc_attr( apply_filters( 'woocommerce_walletmix_icon', $icon ) ) . '" alt="Walletmix Online Payment Gateway" />';
	
	$link="https://www.walletmix.com";
	
	$what_is_walletmix=sprintf( '<a href="%1$s" class="about_walletmix" onclick="javascript:window.open(\'%1$s\',\'WIWalletmix\',\'toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=yes, resizable=yes, width=1060, height=700\'); return false;" title="' . esc_attr__( 'What is Walletmix?', 'woocommerce' ) . '">' . esc_attr__( 'What is Walletmix?', 'woocommerce' ) . '</a>', esc_url( $link ) );
	
	
	return apply_filters( 'woocommerce_gateway_icon', $icon_html . $what_is_walletmix, $this->id );
	
	}
	
	
	
	
	function init_form_fields(){
       	   
	   
	   $this -> form_fields = array(
                'enabled' => array(
                    'title' => __('Enable/Disable', 'mostofa'),
                    'type' => 'checkbox',
                    'label' => __('Enable Walletmix Payment Module.', 'mostofa'),
                    'default' => 'no'),
              
                'merchant_id' => array(
                    'title' => __('Merchant ID', 'mostofa'),
                    'type' => 'text',
                    'description' => __('This id(Merchant ID) available at "merchant profile"  at Walletmix.')),             			
												
				               
            );
    }

       public function admin_options(){
        echo '<h3>'.__('Walletmix Payment Gateway', 'mostofa').'</h3>';
        echo '<p>'.__('Walletmix is most popular payment gateway in Bangladesh').'</p>';
		echo '<p>'.__('copy this url during merchant registration <span style="background-color:#454545;color:#fff; padding:5px 10px;">'.get_site_url().'</span>').'</p>';
        echo '<table class="form-table">';
        // Generate the HTML For the settings form.
        $this -> generate_settings_html();
        echo '</table>';

    }

    /**
     *  There are no payment fields for walletmix, but we want to show the description if set.
     **/
    function payment_fields(){
        if($this -> description) echo wpautop(wptexturize($this -> description));
    }
	
    /**
     * Generate walletmix button link
     **/
	 
	 
    public function generate_walletmix_form($order_id){

       global $woocommerce;
    	
		$order = new WC_Order( $order_id );        
      
		$redirect_url=WC()->api_request_url(get_class($this));
		
		//$currency=$order->get_order_currency(); 
		$currency=get_woocommerce_currency();
		
		 
		$products = "Order-$order_id"."_".date("Y-m-d h:i:s");
		$product_wtihquantity=''; 
		$length=0;
		$quantity=0;
		
		$items = $order->get_items();
		
		foreach ( $items as $item ) {				
		$price=get_post_meta( (int)$item['product_id'], '_price', true);
		$t=$item['qty']*$price;
		$product_wtihquantity.='{'.$item['qty'] . 'x' . $item['name'] . '['.$price.']=['.$t.']}+';
		$quantity+=$item['qty'];
		$length++;				
		}
		
		
		$shippingTotal=$order->get_total_shipping() + $order->get_shipping_tax();
		$shipping=$shippingTotal > 0? round($shippingTotal,2):0;
		
		$couponTotal=$order->get_total_discount();
		$coupon=$couponTotal>0?$couponTotal:0;
		
		$product_wtihquantity.='{shipping rate:'.$shipping.'}-{coupon amount:'.$coupon.'}='.number_format( $order->get_total(), 2, '.', '' );
		
		$options=base64_encode('s='.get_site_url().',i='.$_SERVER['SERVER_ADDR']);
						
		$site_title = get_bloginfo( 'name' );
		$cart_info=$this->merchant_id.','.get_site_url().','.$order_id.':'.$site_title.','.$order -> billing_email.','.$order_id;
				
		$walletmix_args=array(
		'merchant_id' => $this -> merchant_id,
		'order_info' => $cart_info,
		'amount' =>  $order -> order_total,
		'cus_name' => $order -> billing_first_name.' '.$order -> billing_last_name,
		'cus_add1' => $order -> billing_address_1,
		'cus_add2' => $order -> billing_address_2,
		'cus_city' => $order -> billing_city,
		'cus_state' => $order -> billing_state,
		'cus_postcode' => $order -> billing_postcode,
		'cus_country' => $order -> billing_country,
		'cus_phone' => $order -> billing_phone,
		'cus_email' => $order -> billing_email,
		'ship_name' => $order->shipping_first_name.' '.$order->shipping_last_name,
		'ship_add1' => $order->shipping_address_1,
		'ship_add2' => $order->shipping_address_2,
		'ship_city' => $order->shipping_city,
		'ship_state' => $order->shipping_state,
		'ship_postcode' => $order->shipping_postcode,
		'ship_country' => $order->shipping_country,
		'currency' => $currency,
		'callback_url' => $redirect_url ,
		'cancel_url' => esc_url( $order->get_cancel_order_url() ),
		'opt_a' => $options,
		'description' => $product_wtihquantity,
		'bankdescription' => $products,
		'product_length' => $length,
		'quantity' => $quantity,
		);  

        $walletmix_args_array = array();
        foreach($walletmix_args as $key => $value){
          $walletmix_args_array[] = "<input type='hidden' name='$key' value='$value'/>";
        }
        return '<form action="'.$this->url.'" method="post" id="walletmix_payment_form">
            ' . implode('', $walletmix_args_array) . '
            <input type="submit" class="button-alt" id="submit_walletmix_payment_form" value="'.__('Pay via Walletmix', 'mostofa').'" /> <a class="button cancel" href="'.$order->get_cancel_order_url().'">'.__('Cancel order &amp; restore cart', 'mostofa').'</a>
            <script type="text/javascript">
jQuery(function(){
jQuery("body").block(
        {
            message: "<img src=\"'.$woocommerce->plugin_url().'/assets/images/ajax-loader.gif\" alt=\"Redirecting…\" style=\"float:left; margin-right: 10px;\" />'.__('Thank you for your order. We are now redirecting you to Payment Gateway to make payment.', 'mostofa').'",
                overlayCSS:
        {
            background: "#fff",
                opacity: 0.6
    },
    css: {
        padding:        20,
            textAlign:      "center",
            color:          "#555",
            border:         "3px solid #aaa",
            backgroundColor:"#fff",
            cursor:         "wait",
            lineHeight:"32px"
    }
    });
    jQuery("#submit_walletmix_payment_form").click();});</script>
            </form>';


    }
	
	
	
	/**
     * Receipt Page
     **/
    function receipt_page($order){
        echo '<p>'.__('Thank you for your order, please click the button below to pay with Walletmix.', 'mostofa').'</p>';
        echo $this -> generate_walletmix_form($order);
    }
	
	
	
    /**
     * Process the payment and return the result
     **/
    function process_payment($order_id){
  
    	$order = new WC_Order( $order_id ); 
		  		
		return array(
		'result' => 'success',
		'redirect' => $order->get_checkout_payment_url( true )
		);								
		
    }

    /**
     * Check for valid payu server callback
     **/
    function check_walletmix_response(){
        				
		global $woocommerce;				
		/* mostofa edited part */		
		if (isset($_REQUEST['mer_txnid']) && $_REQUEST['mer_txnid']!='') {
		
		$order_id =(int) $_REQUEST['mer_txnid'];				
	    				
		try
		{
		
		$order = new WC_Order( $order_id );
		$status = $_REQUEST['pay_status'];		
		$message = '';
		/* generate note */
		$messageArray=array(
		'Payment status'=>$_POST['pay_status'],
		'Walletmix Transaction ID'=>$_POST['walletmix_txnid'],
		'Your Oder id'=>$_POST['mer_txnid'],
		'Currency merchant'=>$_POST['currency_merchant'],
		'Currency walletmix'=>$_POST['currency'],
		'Currency conversion rate'=>$_POST['convertion_rate'],
		'Receiveable amount after Walletmix service'=>$_POST['store_amount'],
		'Payment date'=>$_POST['pay_time'],
		'Bank Transaction ID'=>$_POST['bank_txn'],
		'Card number'=>$_POST['card_number'],
		'Card name'=>$_POST['card_name'],
		'Card type'=>$_POST['card_type'],
		'Customer IP addresss'=>$_POST['ip_address'],
		'Currency charged in BDT'=>$_POST['walletmix_service_charge_bdt'],
		'Reason'=>$_POST['reason'],
		);
		
		foreach($messageArray as $k=>$v)
		{
		$message .= $k."=".$v."\n";
		}
		
		$message = nl2br(strip_tags($message));
		
		/* check is it success or failed  */
		if($status == 'success')
		{					
		
		if($order -> status == 'processing'){
		}
		else
		{
		$order -> payment_complete();
		$order -> add_order_note($message);
        $woocommerce -> cart -> empty_cart();
		}
		
		}
		elseif($status == 'failed')
		{
		$order -> update_status($status);
		$order -> add_order_note($message);		
		}
		else
		{		
		}
		/* end generate note */
		
		wp_redirect( $this->get_return_url( $order ) );
		exit;
		}
		catch(Exception $e)
		{
		wp_redirect( $this->get_return_url( $order ) );
		exit;
		}
									
		} 
		else
		{
		wp_redirect(get_site_url());
		exit;
		}
		
		/* end mostofa edited part */

    }
		
  
   
}
   /**
     * Add the Gateway to WooCommerce
     **/
    function woocommerce_add_mostofa_walletmix_gateway($methods) {
        $methods[] = 'WC_Mostofa_Walletmix';
        return $methods;
    }

    add_filter('woocommerce_payment_gateways', 'woocommerce_add_mostofa_walletmix_gateway' );
}

?>
